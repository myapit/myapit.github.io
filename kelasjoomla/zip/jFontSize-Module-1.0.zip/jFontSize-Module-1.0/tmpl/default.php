<?php defined('_JEXEC') or die;

/**
 * File       default.php
 * Created    5/9/13 8:35 PM
 * Author     Matt Thomas | matt@betweenbrain.com | http://betweenbrain.com
 * Support    https://github.com/betweenbrain/
 * Copyright  Copyright (C) 2013 betweenbrain llc. All Rights Reserved.
 * License    GNU GPL v3 or later
 */

?>
<div class="jfontsize">
	<a class="jfontsize-button" id="jfontsize-minus">A-</a>
	<a class="jfontsize-button" id="jfontsize-default">A</a>
	<a class="jfontsize-button" id="jfontsize-plus">A+</a>
</div>